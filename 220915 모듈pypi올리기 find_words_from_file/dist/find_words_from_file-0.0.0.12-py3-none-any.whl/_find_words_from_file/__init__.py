from .find_words_from_file import find

__doc__='''
설명이다. 들어라. 독독
'''